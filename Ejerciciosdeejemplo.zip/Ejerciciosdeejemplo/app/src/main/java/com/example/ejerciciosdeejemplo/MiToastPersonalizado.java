package com.example.ejerciciosdeejemplo;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
public class MiToastPersonalizado {
    public static void mostrarMensaje(Context context, String message){
// Inflar el diseño personalizado
        View view = LayoutInflater.from(context).inflate(R.layout.layout_toast, null);
}}
